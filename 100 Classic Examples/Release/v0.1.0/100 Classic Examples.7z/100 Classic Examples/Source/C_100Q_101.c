﻿#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define LENGTH 15

int fnGeometric(int*);
void fnShort(int*);
void fnSwap(int*);
int fnNoRepeat(int*, int);
void fnForward(int*, int, int);

int main(void) {
	int iArray[LENGTH];
	int* piArray = iArray;

	srand((unsigned int)time(0));

	printf("Numbers\t\t: ");
	for (int iLoop = 0; iLoop < LENGTH; iLoop++) {
		iArray[iLoop] = (rand() % 50) + 1;
		printf("%2d ", iArray[iLoop]);
	}
	printf("\n\n");

	printf("Possible ratio\t: [%d]\n\n", fnGeometric(piArray));
	system("pause");
	return 0;
}

int fnGeometric(int* piArray) {
	int iLength = 0, iTempLength = 0, iRatio = 0, iNextRatio = 0, iMaxRatio = 0;
	int* piArrayEND = piArray;
	bool bOneFlag = false;

	fnShort(piArray);
	printf("Shorted\t\t: ");
	for (int iLoop = 0; iLoop < LENGTH; iLoop++) printf("%2d ", *(piArray + iLoop));
	printf("\n\n");

	iLength = fnNoRepeat(piArray, LENGTH);
	if (iLength < 0) {
		bOneFlag = true;
		iLength *= -1;
	}
	printf("Non-Repeat\t: ");
	for (int iLoop = 0; iLoop < iLength; iLoop++) printf("%2d ", *(piArray + iLoop));
	printf("\n\n");

	iTempLength = iLength;
	piArrayEND += iLength - 1;

	int iLoop = 0;
	while (iLength != 1) {
		iTempLength = iLength;
		for (iLoop = 1; iLoop < iTempLength; iLoop++) {
			// Try each unmber ubtil  no reminder, if found, ptr will move to that num and continue div until find the same ratio or hit the head.
			if (iLength > 1 && *(piArrayEND) % *(piArrayEND - iLoop) == 0) {
				iNextRatio = *(piArrayEND) / *(piArrayEND - iLoop);
				piArrayEND -= iLoop;
				iLoop -= iLoop;
				// Found the same ratio
				if (iNextRatio == iRatio && iNextRatio > iMaxRatio) {
					iMaxRatio = iNextRatio;
					iRatio = 0;
					iNextRatio = 0;
					continue;
				}
				// Bigger than Max_ratio then replace iRatio
				if (iNextRatio > iMaxRatio) {
					iRatio = iNextRatio;
					iLoop -= iLoop;
					continue;
				}
			}
			// Stoped at the head
			if (iLength > 2 && piArrayEND == piArray) {
				iRatio = 0;
				iNextRatio = 0;
				iLength--;
				piArrayEND += iLength -1;
				break;
			}
		}
		// Can't find any ratio
		iRatio = 0;
		iNextRatio = 0;
		iLength--;
		if(iLength > 1) piArrayEND--;
	}
	if (!iMaxRatio && bOneFlag == true) iMaxRatio = 1;

	return iMaxRatio;
}

void fnShort(int* piArray) {
	int* piArrayTemp = piArray;
	int iLength, iTempLength;

	iTempLength = iLength = LENGTH;
	while (iLength != 0) {
		if (iTempLength != 1 && *piArrayTemp > * (piArrayTemp + 1)) {
			fnSwap(piArrayTemp);
			piArrayTemp++;
			iTempLength--;
			continue;
		}
		if (iTempLength == 1) {
			iTempLength = --iLength;
			piArrayTemp = piArray;
			continue;
		}
		piArrayTemp++;
		iTempLength--;
	}
}

void fnSwap(int* piArray) {
	int iTemp = 0;

	iTemp = *(piArray + 1);
	*(piArray + 1) = *piArray;
	*piArray = iTemp;
}

int fnNoRepeat(int* piArray, int iLength) {	// There are major bug found in this function, output not correct when too many repeat numbers. Planded to fix in the next buld [beta 02, build 02] (lst97 29052019).
	int iRepeatCounter = 0, iTempLength = iLength;
	int* iTemp = piArray;
	bool bOneFlag = 0;

	while (iLength != 1) {
		if (iLength > 3 && *piArray == *(piArray + 1) && *piArray == *(piArray + 2)) {
			fnForward(piArray + 1, 2, iLength);
			bOneFlag = true;	// final ans ratio = 1 if no ratio
			iRepeatCounter += 2;
			iLength -= 2;
			continue;
		}
		if (iLength > 1 && *piArray == *(piArray + 1)) {
			fnForward(piArray + 1, 1, iLength);
			iRepeatCounter++;
			iLength--;
			piArray++;
			continue;
		}
		iLength--;
		piArray++;
	}
	if (bOneFlag) return -(iTempLength - iRepeatCounter);
	return (iTempLength - iRepeatCounter);
}

// (startPtr, move forward "iNum", Array length)
void fnForward(int* piArray, int iForward, int iArrayLength) {
	for (int iLoop = 0; iLoop < (iArrayLength-1) - iForward; iLoop++) {
		*piArray = *(piArray + iForward);
		piArray++;
		if (iForward == 2 && iLoop == (iArrayLength -1) - iForward -1) {
			*piArray = -1;
			*(piArray + 1) = -1;
		}
		else if(iLoop == (iArrayLength - 1) - iForward - 1) *piArray = -1;
	}
}
