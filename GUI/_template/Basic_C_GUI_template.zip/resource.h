//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDR_MENU                        101
#define IDD_DIALOG_ABOUT                102
#define IDI_ICON                        104
#define IDS_STRING_ABOUTDETAIL          105
#define IDI_IMAGE_ICON                  1001
#define IDC_LABLE_TITLE                 1002
#define IDC_ABOUT_LABLE_TITLE           1002
#define IDC_ABOUT_LABLE_PNAME           1003
#define IDC_ABOUT_LABLE_AUTHOR          1004
#define IDC_ABOUT_LABLE_LICEN           1005
#define ABOUT_IDDETAIL                  1006
#define ABOUT_IDOK                      1007
#define IDC_ABOUT_SYSLINK_GITHUB        1012
#define IDC_ABOUT_LABLE_HOME            1012
#define ID_HELP_ABOUT                   40001
#define ID_PROGRAM_EXIT                 40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
