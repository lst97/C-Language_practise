//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDR_MENU                        101
#define IDD_DIALOG_ABOUT                102
#define IDI_ICON                        103
#define IDS_STRING_ABOUTDETAIL          104
#define IDR_ACCELERATOR                 105
#define IDI_IMAGE_ICON                  1001
#define IDC_ABOUT_LABLE_TITLE           1002
#define IDC_ABOUT_LABLE_PNAME           1003
#define IDC_ABOUT_LABLE_AUTHOR          1004
#define IDC_ABOUT_LABLE_LICEN           1005
#define ABOUT_IDDETAIL                  1006
#define ABOUT_IDOK                      1007
#define IDC_ABOUT_LABLE_HOME            1008
#define ID_HELP_ABOUT                   40001
#define ID_PROGRAM_EXIT                 40002
#define ID_EDIT_CUT                     40003
#define ID_EDIT_COPY                    40004
#define ID_EDIT_PASTE                   40005
#define ID_EDIT_CLEAR                   40006
#define ID_EDIT_RESET                   40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
