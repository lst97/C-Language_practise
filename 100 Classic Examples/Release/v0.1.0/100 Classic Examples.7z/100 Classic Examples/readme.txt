This program took me about 25 days to build, as you can see I am not a genius, if I can do that, I believe you can do that also, nothing is easy. Let's back each other up!

"C_100Q" folder contain all 101 C programs.
Do not delete 'A', 'B', 'C' file.

Question booklet is only avaliable in Chinese(Simplify) for now. (Translate in process)

Enjoy!

Last modify: 29/05/2019 by lst97
