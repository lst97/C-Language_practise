Start day	: 02052019
End dat		: 27052019
Day used	: 25 days