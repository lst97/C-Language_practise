//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_ICON                        101
#define IDR_MENU                        102
#define IDS_STRING_ABOUT                103
#define IDS_STRING_TITLE                104
#define IDS_STRING_OSERROR              105
#define IDD_DIALOG_ABOUT                106
#define IDD_DIALOG_CHANGEBGSTYLE        108
#define ABOUT_IDOK                      1001
#define ABOUT_IDDETAIL                  1002
#define IDC_CHANGEBGSTYLE_RADIO_RED     1006
#define IDC_CHANGEBGSTYLE_RADIO_GREEN   1007
#define IDC_CHANGEBGSTYLE_RADIO_BLUE    1008
#define IDC_CHANGEBGSTYLE_RADIO_RANDOM  1009
#define IDC_CHANGEBGSTYLE_RADIO_RECTANGLE 1010
#define IDC_CHANGEBGSTYLE_RADIO_ELIPSE  1011
#define IDC_CHANGEBGSTYLE_GBCOLOR       1012
#define IDC_CHANGEBGSTYLE_GBFIGURE      1013
#define CHANGEBGSTYLE_IDOK              1014
#define CHANGEBGSTYLE_IDCANCEL          1015
#define IDC_CHANGEBGSTYLE_DEMO          1016
#define ID_HELP_ABOUT                   40001
#define ID_SETTING_CHANGEBGCOLOR        40002
#define ID_CHANGEBGCOLOR_RED            40003
#define ID_CHANGEBGCOLOR_GREEN          40004
#define ID_CHANGEBGCOLOR_BLUE           40005
#define ID_CHANGEBGCOLOR_RANDOM         40006
#define ID_PROGAM_EXIT                  40007
#define ID_SETTING_SETCIRCLE            40010
#define ID_SETTING_CHANGEBGSTYLE        40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40012
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
